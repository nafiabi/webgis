<!--
=========================================================
Material Dashboard - v2.1.2
=========================================================

Product Page: https://www.creative-tim.com/product/material-dashboard
Copyright 2020 Creative Tim (https://www.creative-tim.com)
Coded by Creative Tim

=========================================================
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    WEBGIS Kerusakan Jalan
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
 
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://www.creative-tim.com" class="simple-text logo-normal">
         <img src="../assets/img/logo.png">
         <!-- <h4><b>WEBGIS KERUSAKAN JALAN</b></h4>
          <h6 class=sub-tittle>JALAN NASIONAL PULAU BANGKA,</h6>
          <h6 class=sub-tittle>PROVINSI KEPULAUAN BANGKA BELITUNG</h6> -->
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item  ">
            <a class="nav-link" href="../index.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="map.php">
              <i class="material-icons">location_ons</i>
              <p>Maps</p>
            </a>
          </li>
          <li class="nav-item active ">
            <a class="nav-link" href="javascript:;">
              <i class="material-icons">content_paste</i>
              <p>Ruas Jalan</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="form.php">
              <i class="material-icons">library_books</i>
              <p>Form Pelaporan</p>
            </a>
          <!-- </li>
          <li class="nav-item ">
            <a class="nav-link" href="./icons.html">
              <i class="material-icons">bubble_chart</i>
              <p>Icons</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./map.html">
              <i class="material-icons">location_ons</i>
              <p>Maps</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./notifications.html">
              <i class="material-icons">notifications</i>
              <p>Notifications</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./rtl.html">
              <i class="material-icons">language</i>
              <p>RTL Support</p>
            </a>
          </li>
          <li class="nav-item active-pro ">
            <a class="nav-link" href="./upgrade.html">
              <i class="material-icons">unarchive</i>
              <p>Upgrade to PRO</p>
            </a>
          </li> -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Ruas Jalan</a>
          </div>
           <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
               
                <ul class="navbar-nav">
              <a class="navbar-brand" href="javascript:;">Kerusakan Jalan Nasional Pulau Bangka</a>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

      <div class="content">

        <div class="container-fluid">
          
          <div class="row">
            <div class="col-md-12">
              
              <div class="card">

                <div class="card-header card-header-primary">
                  
                  <h4 class="card-title "><a href="ruas.php"><i class="fas fa-arrow-left"></i></a>&emsp; Ruas 010</h4>
                  <p class="card-category">&emsp;&emsp;&ensp; Bts. Kota Pangkal Pinang - Namang</p>
                  

                </div>

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>
                          No
                        </th>
                        <th>
                          Jenis Kerusakan
                        </th>
                        <th>
                          Tipe Kerusakan
                        </th>
                        <th>
                          Tingkat Resiko
                        </th>
                        <th>
                          Luas (m2)
                        </th>
                        <th>
                          Panjang (m)
                        </th>
                      </thead>
                      <tbody>
                       <tr><td>1</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>SEDANG</td><td>-</td><td>32.0712082733</td><tr>
<tr><td>2</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>28.2660917681999</td><tr>
<tr><td>3</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>SEDANG</td><td>-</td><td>7.15731727752</td><tr>
<tr><td>4</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>19.7353330000999</td><tr>
<tr><td>5</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>18.5242263493999</td><tr>
<tr><td>6</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>24.1472893687999</td><tr>
<tr><td>7</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>5.1540197769</td><tr>
<tr><td>8</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>15.9954667355</td><tr>
<tr><td>9</td><td>RETAK MEMANJANG DAN MELINTANG</td><td>Line</td><td>RENDAH</td><td>-</td><td>3.19091224231</td><tr>
<tr><td>10</td><td>PENURUNAN LAJUR (BAHU)</td><td>Line</td><td>RENDAH</td><td>-</td><td>8.47955793616</td><tr>
<tr><td>11</td><td>RETAK REFLEKSI SAMBUNGAN</td><td>Line</td><td>SEDANG</td><td>-</td><td>8.53264387507</td><tr>
<tr><td>12</td><td>KEGEMUKAN</td><td>Polygon</td><td>SEDANG</td><td>49.4457827064</td><td>-</td><tr>
<tr><td>13</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>87.9643265272</td><td>-</td><tr>
<tr><td>14</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>2.26610433858</td><td>-</td><tr>
<tr><td>15</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>1.21073299995</td><td>-</td><tr>
<tr><td>16</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>11.7520646155</td><td>-</td><tr>
<tr><td>17</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>9.41949387537</td><td>-</td><tr>
<tr><td>18</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.42448710495</td><td>-</td><tr>
<tr><td>19</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>6.18380519931</td><td>-</td><tr>
<tr><td>20</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>3.74513724993</td><td>-</td><tr>
<tr><td>21</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>3.61671786937</td><td>-</td><tr>
<tr><td>22</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>1.88115074172</td><td>-</td><tr>
<tr><td>23</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.233212034549</td><td>-</td><tr>
<tr><td>24</td><td>PEMUAIAN</td><td>Polygon</td><td>RENDAH</td><td>75.5235239854</td><td>-</td><tr>
<tr><td>25</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>4.33933076906</td><td>-</td><tr>
<tr><td>26</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>3.33111980058</td><td>-</td><tr>
<tr><td>27</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>23.5204551847</td><td>-</td><tr>
<tr><td>28</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>17.0943479214</td><td>-</td><tr>
<tr><td>29</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>4.9545874532</td><td>-</td><tr>
<tr><td>30</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>5.02700530418</td><td>-</td><tr>
<tr><td>31</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>12.7008523691</td><td>-</td><tr>
<tr><td>32</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>1.58160671601</td><td>-</td><tr>
<tr><td>33</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>4.67536203936</td><td>-</td><tr>
<tr><td>34</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>3.10426061011</td><td>-</td><tr>
<tr><td>35</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>14.563886451</td><td>-</td><tr>
<tr><td>36</td><td>PEMUAIAN</td><td>Polygon</td><td>RENDAH</td><td>3.20463896098</td><td>-</td><tr>
<tr><td>37</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>1.39777399066</td><td>-</td><tr>
<tr><td>38</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.791297249084</td><td>-</td><tr>
<tr><td>39</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>8.61765495739999</td><td>-</td><tr>
<tr><td>40</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>105.938451873</td><td>-</td><tr>
<tr><td>41</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>12.838185715</td><td>-</td><tr>
<tr><td>42</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>2.25891551008</td><td>-</td><tr>
<tr><td>43</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>31.1674796832</td><td>-</td><tr>
<tr><td>44</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>33.3379519957</td><td>-</td><tr>
<tr><td>45</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>9.07594166394999</td><td>-</td><tr>
<tr><td>46</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.40278805981</td><td>-</td><tr>
<tr><td>47</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.884133570601</td><td>-</td><tr>
<tr><td>48</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>7.86941669235</td><td>-</td><tr>
<tr><td>49</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>3.8310289719</td><td>-</td><tr>
<tr><td>50</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>1.70304552923</td><td>-</td><tr>
<tr><td>51</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>6.55345584176</td><td>-</td><tr>
<tr><td>52</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>8.56128979835</td><td>-</td><tr>
<tr><td>53</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>1.75194220061</td><td>-</td><tr>
<tr><td>54</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>37.2240322526999</td><td>-</td><tr>
<tr><td>55</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>2.31127919062</td><td>-</td><tr>
<tr><td>56</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>23.07558913</td><td>-</td><tr>
<tr><td>57</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>15.0794773946</td><td>-</td><tr>
<tr><td>58</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>18.9636753152</td><td>-</td><tr>
<tr><td>59</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>15.5407481909</td><td>-</td><tr>
<tr><td>60</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>3.53468587095</td><td>-</td><tr>
<tr><td>61</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>6.49006832758</td><td>-</td><tr>
<tr><td>62</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>28.7506697256</td><td>-</td><tr>
<tr><td>63</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.0701024998294</td><td>-</td><tr>
<tr><td>64</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>19.6925458796</td><td>-</td><tr>
<tr><td>65</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>67.0379232677999</td><td>-</td><tr>
<tr><td>66</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>4.73094090182</td><td>-</td><tr>
<tr><td>67</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>20.7163688053</td><td>-</td><tr>
<tr><td>68</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>4.30356578589</td><td>-</td><tr>
<tr><td>69</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>2.00780221081</td><td>-</td><tr>
<tr><td>70</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>24.7355116608</td><td>-</td><tr>
<tr><td>71</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>24.2611512687</td><td>-</td><tr>
<tr><td>72</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>19.3457966305999</td><td>-</td><tr>
<tr><td>73</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>24.6237233212</td><td>-</td><tr>
<tr><td>74</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>SEDANG</td><td>26.7722099419</td><td>-</td><tr>
<tr><td>75</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>TINGGI</td><td>2.50956212601</td><td>-</td><tr>
<tr><td>76</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.159448762683</td><td>-</td><tr>
<tr><td>77</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>0.00051944004641</td><td>-</td><tr>
<tr><td>78</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>11.34227563</td><td>-</td><tr>
<tr><td>79</td><td>PELEPASAN BUTIR</td><td>Polygon</td><td>RENDAH</td><td>4.6711898633</td><td>-</td><tr>
<tr><td>80</td><td>PEMUAIAN</td><td>Polygon</td><td>SEDANG</td><td>12.7401727581</td><td>-</td><tr>
<tr><td>81</td><td>PEMUAIAN</td><td>Polygon</td><td>RENDAH</td><td>0.940510025294</td><td>-</td><tr>
<tr><td>82</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.0481140456494</td><td>-</td><tr>
<tr><td>83</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>4.15848444973</td><td>-</td><tr>
<tr><td>84</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>2.24567317976</td><td>-</td><tr>
<tr><td>85</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.150215989775</td><td>-</td><tr>
<tr><td>86</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.658427225393</td><td>-</td><tr>
<tr><td>87</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.381890990391</td><td>-</td><tr>
<tr><td>88</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.309617245126</td><td>-</td><tr>
<tr><td>89</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.0450630201996</td><td>-</td><tr>
<tr><td>90</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>13.7618149506</td><td>-</td><tr>
<tr><td>91</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>1.62343934907</td><td>-</td><tr>
<tr><td>92</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>5.5995656472</td><td>-</td><tr>
<tr><td>93</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>2.12878103468</td><td>-</td><tr>
<tr><td>94</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.550301465349</td><td>-</td><tr>
<tr><td>95</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>1.26227440973</td><td>-</td><tr>
<tr><td>96</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>1.47554217041</td><td>-</td><tr>
<tr><td>97</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>2.35722311939</td><td>-</td><tr>
<tr><td>98</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.579292500658</td><td>-</td><tr>
<tr><td>99</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>4.10390999299</td><td>-</td><tr>
<tr><td>100</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>6.92758599148</td><td>-</td><tr>
<tr><td>101</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>2.29500842092</td><td>-</td><tr>
<tr><td>102</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>3.09201188014</td><td>-</td><tr>
<tr><td>103</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.199458289625</td><td>-</td><tr>
<tr><td>104</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>1.03122596614</td><td>-</td><tr>
<tr><td>105</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>1.7573459954</td><td>-</td><tr>
<tr><td>106</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.332384835002</td><td>-</td><tr>
<tr><td>107</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.218470499426</td><td>-</td><tr>
<tr><td>108</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.108463760314</td><td>-</td><tr>
<tr><td>109</td><td>LUBANG</td><td>Polygon</td><td>RENDAH</td><td>0.0940418098402</td><td>-</td><tr>
<tr><td>110</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.206920470023</td><td>-</td><tr>
<tr><td>111</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>4.82478039077</td><td>-</td><tr>
<tr><td>112</td><td>LUBANG</td><td>Polygon</td><td>SEDANG</td><td>0.0578777248402</td><td>-</td><tr>
<tr><td>113</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>2.28272609529</td><td>-</td><tr>
<tr><td>114</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>7.40835410104</td><td>-</td><tr>
<tr><td>115</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>74.7757278325999</td><td>-</td><tr>
<tr><td>116</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>2.37861899008</td><td>-</td><tr>
<tr><td>117</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>5.00478163894</td><td>-</td><tr>
<tr><td>118</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>10.3137859429999</td><td>-</td><tr>
<tr><td>119</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>17.9742248509</td><td>-</td><tr>
<tr><td>120</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>18.5431176784</td><td>-</td><tr>
<tr><td>121</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>25.1063008632</td><td>-</td><tr>
<tr><td>122</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>76.7695913870999</td><td>-</td><tr>
<tr><td>123</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>12.6648747198</td><td>-</td><tr>
<tr><td>124</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>12.8782965611</td><td>-</td><tr>
<tr><td>125</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>36.1969643455</td><td>-</td><tr>
<tr><td>126</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>22.5005592127</td><td>-</td><tr>
<tr><td>127</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>9.14920859961</td><td>-</td><tr>
<tr><td>128</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>30.8891942163</td><td>-</td><tr>
<tr><td>129</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>42.3766969094999</td><td>-</td><tr>
<tr><td>130</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>19.230980787</td><td>-</td><tr>
<tr><td>131</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>57.7788912514999</td><td>-</td><tr>
<tr><td>132</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>7.34931033991</td><td>-</td><tr>
<tr><td>133</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>13.6835688085</td><td>-</td><tr>
<tr><td>134</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>11.6748486451</td><td>-</td><tr>
<tr><td>135</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>14.3641141892</td><td>-</td><tr>
<tr><td>136</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>14.2455390655999</td><td>-</td><tr>
<tr><td>137</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>74.8813208893</td><td>-</td><tr>
<tr><td>138</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>1.69085157528</td><td>-</td><tr>
<tr><td>139</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>11.2927888425</td><td>-</td><tr>
<tr><td>140</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>2.43934061908</td><td>-</td><tr>
<tr><td>141</td><td>PENGAUSAN AGREGAT</td><td>Polygon</td><td>-</td><td>4.75373051066</td><td>-</td><tr>
<tr><td>142</td><td>AMBLES</td><td>Polygon</td><td>RENDAH</td><td>5.92755297487</td><td>-</td><tr>
<tr><td>143</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>20.236374776</td><td>-</td><tr>
<tr><td>144</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>12.4268500415</td><td>-</td><tr>
<tr><td>145</td><td>RETAK BLOK</td><td>Polygon</td><td>RENDAH</td><td>11.1323741704</td><td>-</td><tr>
<tr><td>146</td><td>RETAK BLOK</td><td>Polygon</td><td>RENDAH</td><td>1.48328009503</td><td>-</td><tr>
<tr><td>147</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>14.7865964391</td><td>-</td><tr>
<tr><td>148</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>6.54269829185</td><td>-</td><tr>
<tr><td>149</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>6.18538270606</td><td>-</td><tr>
<tr><td>150</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>6.87244486955</td><td>-</td><tr>
<tr><td>151</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.37589643037</td><td>-</td><tr>
<tr><td>152</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>20.5184523319</td><td>-</td><tr>
<tr><td>153</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>7.92428836985</td><td>-</td><tr>
<tr><td>154</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.20904099976</td><td>-</td><tr>
<tr><td>155</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.09223356934</td><td>-</td><tr>
<tr><td>156</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>12.7362992017</td><td>-</td><tr>
<tr><td>157</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>2.8805328588</td><td>-</td><tr>
<tr><td>158</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>5.27117828775</td><td>-</td><tr>
<tr><td>159</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>2.28437132699</td><td>-</td><tr>
<tr><td>160</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>4.99747252404</td><td>-</td><tr>
<tr><td>161</td><td>RETAK BLOK</td><td>Polygon</td><td>RENDAH</td><td>1.83804958552</td><td>-</td><tr>
<tr><td>162</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>8.77589464155</td><td>-</td><tr>
<tr><td>163</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.43956107571</td><td>-</td><tr>
<tr><td>164</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>16.4015011641</td><td>-</td><tr>
<tr><td>165</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.10910570734</td><td>-</td><tr>
<tr><td>166</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>23.0782027051999</td><td>-</td><tr>
<tr><td>167</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>6.37349953434</td><td>-</td><tr>
<tr><td>168</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>9.00463889447</td><td>-</td><tr>
<tr><td>169</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>28.7270422401999</td><td>-</td><tr>
<tr><td>170</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>6.99204868731</td><td>-</td><tr>
<tr><td>171</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>9.13170619117999</td><td>-</td><tr>
<tr><td>172</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>21.9063059271</td><td>-</td><tr>
<tr><td>173</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>14.2694848441</td><td>-</td><tr>
<tr><td>174</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>2.11539338783</td><td>-</td><tr>
<tr><td>175</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>2.69230240395</td><td>-</td><tr>
<tr><td>176</td><td>RETAK BLOK</td><td>Polygon</td><td>RENDAH</td><td>7.44541765701</td><td>-</td><tr>
<tr><td>177</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>5.77756853585</td><td>-</td><tr>
<tr><td>178</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>11.4869200786</td><td>-</td><tr>
<tr><td>179</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.37176843016</td><td>-</td><tr>
<tr><td>180</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.60768118106</td><td>-</td><tr>
<tr><td>181</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>6.54184649677</td><td>-</td><tr>
<tr><td>182</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>17.0718743057</td><td>-</td><tr>
<tr><td>183</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>11.2532000139</td><td>-</td><tr>
<tr><td>184</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>32.9449727630999</td><td>-</td><tr>
<tr><td>185</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.59144842105</td><td>-</td><tr>
<tr><td>186</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>8.62834903411</td><td>-</td><tr>
<tr><td>187</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>12.947256398</td><td>-</td><tr>
<tr><td>188</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>1.4715267258</td><td>-</td><tr>
<tr><td>189</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.8090727821</td><td>-</td><tr>
<tr><td>190</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>1.95680268534</td><td>-</td><tr>
<tr><td>191</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.03726462736</td><td>-</td><tr>
<tr><td>192</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.29169009086</td><td>-</td><tr>
<tr><td>193</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>7.01830390743</td><td>-</td><tr>
<tr><td>194</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.82167239306</td><td>-</td><tr>
<tr><td>195</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>14.2353919882</td><td>-</td><tr>
<tr><td>196</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>25.7110708396</td><td>-</td><tr>
<tr><td>197</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.15955811585</td><td>-</td><tr>
<tr><td>198</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>0.0218628449682</td><td>-</td><tr>
<tr><td>199</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>7.1214731704</td><td>-</td><tr>
<tr><td>200</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>3.4934031048</td><td>-</td><tr>
<tr><td>201</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>4.60273186938</td><td>-</td><tr>
<tr><td>202</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>1.27764910539</td><td>-</td><tr>
<tr><td>203</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>2.98560790946</td><td>-</td><tr>
<tr><td>204</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>14.5782754918999</td><td>-</td><tr>
<tr><td>205</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>RENDAH</td><td>1.18516820095</td><td>-</td><tr>
<tr><td>206</td><td>RETAK BLOK</td><td>Polygon</td><td>RENDAH</td><td>12.4138377519999</td><td>-</td><tr>
<tr><td>207</td><td>RETAK SELIP</td><td>Polygon</td><td>RENDAH</td><td>2.3899182645</td><td>-</td><tr>
<tr><td>208</td><td>RETAK KULIT BUAYA</td><td>Polygon</td><td>SEDANG</td><td>76.6499471212</td><td>-</td><tr>
<tr><td>209</td><td>SUNGKUR</td><td>Polygon</td><td>RENDAH</td><td>9.26578902315</td><td>-</td><tr>
<tr><td>210</td><td>TAMBALAN</td><td>Polygon</td><td>SEDANG</td><td>3.92206899616</td><td>-</td><tr>
<tr><td>211</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>14.5218904104999</td><td>-</td><tr>
<tr><td>212</td><td>TAMBALAN</td><td>Polygon</td><td>SEDANG</td><td>11.966160754</td><td>-</td><tr>
<tr><td>213</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>4.24795136572</td><td>-</td><tr>
<tr><td>214</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>1.08483287402</td><td>-</td><tr>
<tr><td>215</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>5.84785981036</td><td>-</td><tr>
<tr><td>216</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>6.47557216085</td><td>-</td><tr>
<tr><td>217</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>14.347077534</td><td>-</td><tr>
<tr><td>218</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>1.79198620023</td><td>-</td><tr>
<tr><td>219</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>10.9420028439999</td><td>-</td><tr>
<tr><td>220</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>9.12150969946</td><td>-</td><tr>
<tr><td>221</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>23.5683719809</td><td>-</td><tr>
<tr><td>222</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>31.9237174784999</td><td>-</td><tr>
<tr><td>223</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>20.7876444467</td><td>-</td><tr>
<tr><td>224</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>3.85756935922</td><td>-</td><tr>
<tr><td>225</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>19.6393326514</td><td>-</td><tr>
<tr><td>226</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>6.20936155519</td><td>-</td><tr>
<tr><td>227</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>10.8575958451</td><td>-</td><tr>
<tr><td>228</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>5.8099148044</td><td>-</td><tr>
<tr><td>229</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>6.28779476625</td><td>-</td><tr>
<tr><td>230</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>57.8615187807999</td><td>-</td><tr>
<tr><td>231</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>16.3593363867999</td><td>-</td><tr>
<tr><td>232</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>3.96619811827</td><td>-</td><tr>
<tr><td>233</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>12.0510160388</td><td>-</td><tr>
<tr><td>234</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>29.7402017235999</td><td>-</td><tr>
<tr><td>235</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>24.8605073881999</td><td>-</td><tr>
<tr><td>236</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>8.98426263306999</td><td>-</td><tr>
<tr><td>237</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>25.9946916198</td><td>-</td><tr>
<tr><td>238</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>3.65064633604</td><td>-</td><tr>
<tr><td>239</td><td>TAMBALAN</td><td>Polygon</td><td>SEDANG</td><td>1.81126323013</td><td>-</td><tr>
<tr><td>240</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>9.03029785142</td><td>-</td><tr>
<tr><td>241</td><td>TAMBALAN</td><td>Polygon</td><td>RENDAH</td><td>31.7174678065999</td><td>-</td><tr>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
      <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
      <a href="#" data-toggle="dropdown">
        <i class="fa fa-cog fa-2x"> </i>
      </a>
      <ul class="dropdown-menu">
        <li class="header-title"> Sidebar Filters</li>
        <li class="adjustments-line">
          <a href="javascript:void(0)" class="switch-trigger active-color">
            <div class="badge-colors ml-auto mr-auto">
              <span class="badge filter badge-purple" data-color="purple"></span>
              <span class="badge filter badge-azure" data-color="azure"></span>
              <span class="badge filter badge-green" data-color="green"></span>
              <span class="badge filter badge-warning" data-color="orange"></span>
              <span class="badge filter badge-danger" data-color="danger"></span>
              <span class="badge filter badge-rose active" data-color="rose"></span>
            </div>
            <div class="clearfix"></div>
          </a>
        </li>
        <li class="header-title">Images</li>
        <li class="active">
          <a class="img-holder switch-trigger" href="javascript:void(0)">
            <img src="../assets/img/sidebar-1.jpg" alt="">
          </a>
        </li>
        <li>
          <a class="img-holder switch-trigger" href="javascript:void(0)">
            <img src="../assets/img/sidebar-2.jpg" alt="">
          </a>
        </li>
        <li>
          <a class="img-holder switch-trigger" href="javascript:void(0)">
            <img src="../assets/img/sidebar-3.jpg" alt="">
          </a>
        </li>
        <li>
          <a class="img-holder switch-trigger" href="javascript:void(0)">
            <img src="../assets/img/sidebar-4.jpg" alt="">
          </a>
        </li>
        <div>
          <ul>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>

          </ul>
        </div>
      </ul>
      </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="../assets/js/plugins/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="../assets/js/plugins/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="../assets/js/plugins/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="../assets/js/plugins/bootstrap-selectpicker.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="../assets/js/plugins/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="../assets/js/plugins/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="../assets/js/plugins/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="../assets/js/plugins/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="../assets/js/plugins/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../assets/js/plugins/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="../assets/js/plugins/arrive.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="../assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
</body>

</html>